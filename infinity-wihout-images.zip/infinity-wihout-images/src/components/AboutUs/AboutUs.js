import React, {Component, Fragment} from 'react';
import {Col, Container, Row} from "react-bootstrap";

class AboutUs extends Component {
    render() {
        return (
            <Fragment>
                <Container className="mt-5">
                    <Row>
                        <Col sm={12} lg={12} md={12}>
                            <h1 className="AboutName text-justify">About Us</h1>
                            <hr/>
                            <p className="AboutDescription text-justify">

                                Founded in January 2015 and headquartered in Sylhet City, in order to help companies with their IT solutions.
                                Our initial focus was providing complete information technology solutions for companies. In response
                                to customer needs and in order to fully cover the range of IT services. Today, we deliver the most
                                comprehensive suite of managed IT services to small and medium-sized businesses across Bangladesh
                                and the World. Our proven service portfolio meets the varying needs of customers with
                                implementation services or complete outsourced and Hosted IT solutions. Our known Quality Service allows
                                us to provide all our customers with an effcient, seamless and worry-free “Remote IT department.
                            </p>

                        </Col>
                    </Row>
                </Container>

            </Fragment>

        );
    }
}

export default AboutUs;